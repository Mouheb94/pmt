package com.rendu.backend.enums;

public enum RoleName {
    ADMIN,
    MEMBRE,
    OBSERVATOR,
}
