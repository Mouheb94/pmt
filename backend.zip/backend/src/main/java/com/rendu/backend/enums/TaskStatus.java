package com.rendu.backend.enums;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}
