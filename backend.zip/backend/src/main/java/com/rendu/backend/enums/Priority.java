package com.rendu.backend.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
